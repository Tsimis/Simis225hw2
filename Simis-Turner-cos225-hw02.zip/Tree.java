public class Tree {
    public int IDNum;
    public int Age;
    public String Species;
    public boolean Planted=false;

    public Tree(int IDNum, int Age, String Species){
        this.IDNum=IDNum;
        this.Age=Age;
        this.Species=Species;
    }
}
    