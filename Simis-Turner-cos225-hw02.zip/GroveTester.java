public class GroveTester {
    public static void main(String[] args){
        Grove Grove1 = new Grove("GroveOne");
        System.out.println(Grove1.toString());
        Tree Spruce1= new Tree(1,37,"Spruce");
        Tree Spruce2= new Tree(2,37,"Spruce");
        Tree Spruce3= new Tree(3,37,"Spruce");
        Tree Spruce4= new Tree(4,37,"Spruce");
        Tree Spruce5= new Tree(5,37,"Spruce");
        Tree Spruce6= new Tree(6,37,"Spruce");
        Tree Spruce7= new Tree(7,37,"Spruce");
        Grove1.PlantTree(Spruce1);
        Grove1.PlantTree(Spruce2);
        Grove1.PlantTree(Spruce3);
        Grove1.PlantTree(Spruce4);
        Grove1.PlantTree(Spruce5);
        Grove1.PlantTree(Spruce6);
        Grove1.PlantTree(Spruce7);
        System.out.println(Grove1.toString());
        Grove1.RemoveTree(3);
        Grove1.RemoveTree(5);
        System.out.println(Grove1.toString());
        Tree Maple= new Tree(8,13,"Maple");
        Grove1.PlantTree(Maple);
        System.out.println(Grove1.toString());
    }
}
