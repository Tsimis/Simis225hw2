public class Grove {
    public Tree[] TreeArray;
    public String GroveName;

    public Grove(String GroveName){
        this.GroveName=GroveName;
        this.TreeArray = new Tree[12];
        for ( int i =0; i < 12;i++){
            this.TreeArray[i]= new Tree(0,0,"none");
            this.TreeArray[i].Planted=false;

        }

    }  
    public int PlantTree(Tree tree){
        int TreeIndex = -1;
        for ( int i =0; i < 12;i++){
            if (this.TreeArray[i].Planted==false){
                this.TreeArray[i].Planted=true;
                TreeIndex=i;
                return TreeIndex;
            }
        }
        return TreeIndex;
    }
    public int RemoveTree(int Index){
        this.TreeArray[Index].Planted=false;
        return 0;
    }
    public String toString(){
        int TreeCounter=0;
        for  ( int i =0; i < 12;i++){
            if (this.TreeArray[i].Planted==true){
                TreeCounter++;
            }
        }
        return ""+TreeCounter;
    }
    
}
